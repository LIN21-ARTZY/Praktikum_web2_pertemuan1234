<div id="top" class="row mb-3">
  <div class="col">
    <h3>Hapus Data Bagian</h3>
  </div>
  <div class="col">
    <a href="?page=bagian" class="btn btn-primary float-end">
      <i class="fa fa-arrow-circle-left"></i>
      Kembali
    </a>
  </div>
</div>
<div id="pesan" class="row mb-3">
  <div class="col">
    <?php
    include "database/connection.php";

    $id = $_GET['id'];
    $deleteSQL = "DELETE FROM bagian WHERE id = $id";
    $resultDelete = mysqli_query($connection, $deleteSQL);
    if (!$resultDelete) { ?>
      <div class="alert alert-danger" role="alert">
        <i class="fa fa-exclamation-circle"></i>
        <?php echo mysqli_error($connection) ?>
      </div> <?php
    } else { ?>
      <div class="alert alert-success" role="alert">
        <i class="fa fa-check-circle"></i>
        Hapus data berhasil
      </div>
      <meta http-equiv="refresh" content="2;url=?page=bagian"> <?php
    }
    ?>
  </div>
</div>
